package com.tian.repository;

import com.tian.entity.Customer;

public interface CustomerRepository {
    public Customer findById(long id);
}
