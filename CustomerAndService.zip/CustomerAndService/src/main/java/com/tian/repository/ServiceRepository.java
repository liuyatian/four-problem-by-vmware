package com.tian.repository;

import com.tian.entity.Service;

public interface ServiceRepository {
    public Service findById(long id);
}
