package com.tian.test;

import com.tian.entity.Service;
import com.tian.repository.ServiceRepository;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.InputStream;

public class Test1 {
    public static void main(String[] args) {
        InputStream inputStream = Test.class.getClassLoader().getResourceAsStream("config.xml");
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        SqlSessionFactory sqlSessionFactory = sqlSessionFactoryBuilder.build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        CustomerRepository customerRepository = sqlSession.getMapper(CustomerRepository.class);
        Customer customer= customerRepository.findById(1L);
        System.out.println(customer.getServices());
        sqlSession.close();
    }
}
