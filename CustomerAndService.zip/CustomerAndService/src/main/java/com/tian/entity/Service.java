package com.tian.entity;

import lombok.Data;

import java.util.List;

@Data
public class Service {
    private long id;
    private String name;
    private List<Customer> customers;
}
